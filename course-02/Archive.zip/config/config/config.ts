export const config = {
  "dev": {
    "username": "thedatabaseuda",
    "password": "thedatabaseuda",
    "database": "thedatabaseuda",
    "host": "thedatabaseuda.c2w6sb7fitvm.us-east-2.rds.amazonaws.com",
    "dialect": "postgres",
    "aws_region": "us-east-2",
    "aws_profile": "DEPLOYED",
    "aws_media_bucket": "udagram-nalsadi-dev"
  },
  "prod": {
    "username": "",
    "password": "",
    "database": "udagram_prod",
    "host": "",
    "dialect": "postgres"
  }
}
